# GetPQ.ps1 - Henter Pocket Query zip-filer fra Gmail via IMAP
param(
    [Parameter(Mandatory=$true)][string]$User,
    [Parameter(Mandatory=$true)][string]$Pass,
    [Parameter(Mandatory=$true)][string]$OutDir
)
$LogFile = "C:\pqfiler\GetPQ_debug.log"
function Log($msg) { $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"; "$ts  $msg" | Out-File -FilePath $LogFile -Append -Encoding UTF8 }
if (Test-Path $LogFile) { Remove-Item $LogFile -Force }
Log "=== GetPQ startet === User: $User  OutDir: $OutDir"
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir -Force | Out-Null; Log "Oprettede: $OutDir" }
try {
    $tc = New-Object System.Net.Sockets.TcpClient; $tc.Connect("imap.gmail.com", 993)
    $ssl = New-Object System.Net.Security.SslStream($tc.GetStream(), $false, { $true })
    $ssl.AuthenticateAsClient("imap.gmail.com")
    $r = New-Object System.IO.StreamReader($ssl)
    $w = New-Object System.IO.StreamWriter($ssl); $w.AutoFlush = $true
    function Cmd($tag,$cmd) { $w.WriteLine("$tag $cmd"); $res=New-Object System.Collections.Generic.List[string]; do { $l=$r.ReadLine(); if ($l -ne $null) { $res.Add($l) } } while (($l -ne $null) -and ($l -notmatch "^$tag (OK|NO|BAD)")); return $res.ToArray() }
    $r.ReadLine()|Out-Null
    $lr = @(Cmd "A1" "LOGIN `"$User`" `"$Pass`"")
    if ($lr[-1] -notmatch "^A1 OK") { Log "Login fejl"; exit 1 }
    Cmd "A2" "SELECT INBOX"|Out-Null
    $trash = "[Gmail]/Trash"
    $lsr = @(Cmd "A0" "LIST `"`" `"*`"")
    foreach ($m in $lsr) { if ($m -match '^\* LIST \([^)]*\\Trash[^)]*\) "[^"]*" "?([^"]+)"?\s*$') { $trash = $Matches[1] } }
    Log ("Papirkurv-mappe: " + $trash)
    function Ids($resp) { $ln = $resp|Where-Object{$_ -match "^\* SEARCH"}; if ($ln) { return @(($ln -replace "^\* SEARCH\s*","").Trim().Split(" ")|Where-Object{$_ -match "^\d+$"}) }; return @() }
    $Crit = @('FROM "no-reply@geocaching.com"', 'SUBJECT "Pocket Query"', 'FROM "pqklub"')
    $ids = @()
    foreach ($c in $Crit) {
        $found = @(Ids (Cmd "A3" ("SEARCH " + $c + " UNSEEN")))
        Log ("Ulaeste mails (" + $c + "): " + $found.Count)
        foreach ($x in $found) { if ($ids -notcontains $x) { $ids += $x } }
    }
    # Hoejeste id foerst: Gmail fjerner slettede mails med det samme og renummererer de HOEJERE ids
    $ids = @($ids|Sort-Object {[int]$_} -Descending)
    if ($ids.Count -eq 0) { Log "Ingen nye PQ-mails"; $w.WriteLine("A99 LOGOUT"); exit 0 }
    Log "Fandt $($ids.Count) mail(s)"
    foreach ($id in $ids) {
        $ff = Cmd "A4" "FETCH $id BODY.PEEK[]"
        $fn=""; $b64=New-Object System.Collections.Generic.List[string]; $inB64=$false; $sawB64=$false; $saved=0; $sawZip=$false; $hdr=@()
        foreach ($line in $ff) {
            if ($line -match "^Content-(Type|Disposition):" -and $hdr.Count -lt 8) { $hdr += $line.Trim() }
            if ($line.StartsWith("--")) { $sawB64=$false }
            if ($line -match 'name="?([^"]+\.zip)"?') { $fn=$Matches[1]; $sawZip=$true; if ($sawB64) { $inB64=$true } }
            if ($line -match "Content-Transfer-Encoding: base64") { $sawB64=$true; if ($fn -ne "") { $inB64=$true } }
            if ($inB64) {
                if ($line -match "^[A-Za-z0-9+/=]{1,}$") { $b64.Add($line) }
                elseif ($b64.Count -gt 0) {
                    try { $bytes=[Convert]::FromBase64String(($b64 -join "")); $op=Join-Path $OutDir $fn; [IO.File]::WriteAllBytes($op,$bytes); Log "Gemt: $op"; $saved++ } catch { Log "Fejl: $_" }
                    $inB64=$false; $b64.Clear(); $fn=""; $sawB64=$false
                }
            }
        }
        Log ("Mail " + $id + ": " + ($hdr -join " | "))
        if ($saved -gt 0) {
            Cmd "A5" "STORE $id +FLAGS (\Seen)"|Out-Null
            $cp = @(Cmd "A6" "COPY $id `"$trash`"")
            if ($cp[-1] -match "^A6 OK") {
                Cmd "A7" "STORE $id +FLAGS (\Deleted)"|Out-Null
                Log ("Mail " + $id + ": markeret som laest og flyttet til papirkurv")
            } else {
                Log ("Mail " + $id + ": kunne ikke flyttes til papirkurv (" + $cp[-1] + ") - markeret som laest, ligger i indbakken")
            }
        } elseif (-not $sawZip) {
            Log "Mail $($id): ingen zip - markeret som laest"
            Cmd "A5" "STORE $id +FLAGS (\Seen)"|Out-Null
        } else {
            Log "Mail $($id): zip fundet men ikke gemt - lader den ligge"
        }
    }
    Cmd "A8" "EXPUNGE"|Out-Null
    $w.WriteLine("A99 LOGOUT"); $ssl.Close(); $tc.Close()
    Log "Faerdig"
} catch { Log "FEJL: $_"; exit 1 }
