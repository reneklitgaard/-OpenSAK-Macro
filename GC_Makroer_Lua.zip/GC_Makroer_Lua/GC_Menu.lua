-- OpenSAK Macro
-- Name: GC Makroer
-- Author: René (ported from the GSAK macro suite GC_Menu.gsk)
-- Version: 3.1
-- Requires-API: 3
-- Description: Menu with D/T matrices (month, streak, weekday, cache type), missing cache types, year calendar, attributes, corrected notes and PQ import. Danish / English.
-- Permissions: write, open, read-files, write-files
--
-- Known limitations / Kendte begrænsninger:
-- - Fetching PQ mails from Gmail is not possible in the Lua sandbox (no IMAP, no
--   programs). "Import PQ" imports the zip files in the PQ folder; GetPQ.ps1 fetches them.
-- - Reports are HTML pages opened in the browser. A browser cannot set a filter in
--   OpenSAK, so most reports offer "Set filter" in their dialog instead.
-- - OpenSAK lets a macro open at most 5 files per run; after that the report's
--   path is shown instead.
-- - Language (Dansk / English) is chosen under Settings.

local DEFAULT_LANG = "da"

-- ── Translations ─────────────────────────────────────────────────────────
local STR = {}
STR.da = {
  title = "GC Makroer",
  active_db = "(aktiv database)",
  footer = "Lavet af GC Makroer (OpenSAK Lua) ",
  open_limit = "Rapporten er gemt her (OpenSAK åbner højst 5 filer pr. kørsel – åbn den selv, eller kør makroen igen):\n%s",
  open_fail = "Rapporten er gemt her, men kunne ikke åbnes automatisk:\n%s\n(%s)",
  within = "inden %s km",
  total_word = "i alt",
  filter_none = "Der er ingen ufundne caches, der matcher – filteret er uændret.",
  months = { "Januar", "Februar", "Marts", "April", "Maj", "Juni", "Juli", "August", "September", "Oktober", "November", "December" },
  months_short = { "Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec" },
  weekdays = { "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag", "Søndag" },
  weekdays_short = { "Man", "Tir", "Ons", "Tor", "Fre", "Lør", "Søn" },
  weekdays_2 = { "Ma", "Ti", "On", "To", "Fr", "Lø", "Sø" },
  after_opts = { "Behold zip-filerne", "Flyt til undermappen 'importeret'", "Slet zip-filerne" },
  imported_dir = "importeret",
  date_kinds = { "Fundet dato", "Placed date" },
  streak_modes = { "Intet filter", "Sæt filter: kombinationer der mangler måneder",
                   "Sæt filter: klarede kombinationer (sikre streak-cacher)" },
  -- settings
  cfg_title = "%s – Indstillinger",
  centre_label = "Centerpunkt (vælges i værktøjslinjen): %s",
  centre_coords = "koordinater",
  centre_none = "ikke valgt",
  f_found_db = "Database med fundne caches",
  f_unfound_db = "Database med ufundne caches",
  f_import_db = "Database til PQ-import",
  f_radius = "Radius fra centerpunkt (0 = ingen)",
  f_pq_folder = "Mappe med PQ zip-filer",
  f_after = "Efter import",
  f_lang = "Sprog / Language",
  -- shared report words
  subtitle_found = "Fundne: %s",
  tile_missing = "mangler",
  tile_finds_total = "fund i alt",
  col_weekday = "Ugedag",
  col_found = "Fundet",
  col_missing = "Mangler",
  col_type = "Type",
  col_date = "Dato",
  -- month matrix
  month_title = "Måneds Matrix – %s",
  found_in_month = "fund i %s",
  of12_missing = "af 12 mdr mangler",
  banner_month = "🎉 Tillykke! Du har fundet alle D/T-kombinationer i %s 🎉",
  tile_combos_month = "kombinationer fundet i %s",
  tile_possible = "mangler, men har ufundne muligheder (%s)",
  note_month = "Grøn: antal fund i %s. Rød: hvor mange af årets 12 måneder, kombinationen mangler, og hvor mange ufundne caches der findes (%s). Grå: ingen ufundne muligheder.",
  -- streak
  streak_all12 = "alle 12 måneder",
  streak_months_missing = "måneder mangler",
  tile_complete = "klarede kombinationer (alle 12 måneder)",
  tile_months_missing_total = "måneder der mangler i alt",
  note_streak = "Tallet i en rød celle er antal måneder (ud af 12), hvor du endnu ikke har fundet en cache med den D/T-kombination. Det andet tal er ufundne caches med kombinationen (%s).",
  -- weekday / type matrix
  wd_title = "Ugedage Matrix",
  wd_finds = "fund",
  wd_missing_cell = "mangler",
  combos_heading = "%s – %d / 81 kombinationer fundet",
  tm_title = "D/T-matrix pr. cache-type",
  unfound_cell = "ufundne %s",
  -- cache types report
  ct_title = "Manglende cache-typer",
  ct_next_days = "De næste %d dage",
  ct_note = "✓ = du har fundet den type på den dato (i et hvilket som helst år).",
  tile_days_shown = "datoer vist",
  tile_types_missing = "typer der mangler i perioden",
  ct_by_weekday = "Cache-typer pr. ugedag",
  ct_by_dom = "Cache-typer pr. dag i måneden",
  ct_dt_wd = "D/T-kombinationer pr. ugedag – manglende",
  ct_dt_dom = "D/T-kombinationer pr. dag i måneden – manglende",
  n_missing = "%d mangler",
  none_missing = "Ingen manglende kombinationer",
  dom_summary = "%d. – %d mangler",
  -- year calendar
  yc_title = "Årskalender – %s",
  tile_dates_with = "datoer med fund af typen",
  tile_dates_missing = "datoer der mangler",
  yc_note = "Grøn = du har fundet typen på den dato (i et hvilket som helst år). Rød = mangler. Guld ramme = i dag.",
  -- attributes
  all_pos = "Alle positive attributter",
  all_neg = "Alle negative attributter",
  attr_fallback = "attribut %s",
  ac_title = "Attribut Kalender – %s",
  ac_placed_note = " · placed date = datoen cachen blev lagt ud (tæller dine fund)",
  col_attribute = "Attribut",
  col_days_covered = "Datoer dækket",
  col_days_missing = "Datoer mangler",
  col_total_finds = "Fund i alt",
  am_title = "Attribut Matrix",
  col_dt_found = "D/T fundet",
  col_dt_poss = "D/T med muligheder",
  no_attrs = "Der er ingen attributter på dine fund i databasen.",
  -- corrected
  corr_prompt = "Hvilke caches skal have deres corrected-koordinater skrevet i noten?",
  corr_scopes = { "Den markerede cache", "Alle caches i den viste liste", "Hele databasen" },
  corr_none_selected = "Ingen cache er markeret i listen.",
  corr_no_coords = "Ingen af caches har corrected-koordinater.",
  corr_all_done = "Alle %d noter er allerede opdateret.",
  corr_confirm = "%d noter får linjen ~*Corrected: …*~ (af %d caches med corrected-koordinater). Fortsæt?",
  corr_done = "%d noter opdateret.",
  -- import
  imp_no_folder = "PQ-mappen findes ikke: %s\nVælg den under Indstillinger.",
  imp_no_zips = "Der ligger ingen zip-filer i %s.\nHent PQ'erne først (fx med GetPQ.ps1) – OpenSAK's makroer kan ikke hente mails fra Gmail.",
  imp_confirm = "%d zip-filer i %s importeres i databasen '%s'. Efter importen: %s.\nFortsæt?",
  imp_failed = "Importen blev ikke gennemført korrekt – zip-filerne er ikke rørt. Se makro-outputtet.",
  imp_done = "Import færdig: %d nye og %d opdaterede caches.",
  -- dialogs / menu
  f_month = "Måned",
  f_filter_month = "Sæt filter i OpenSAK bagefter (ufundne caches, der mangler i måneden)",
  f_filter = "Filter",
  f_weekday = "Ugedag",
  all_weekdays = "Alle ugedage",
  f_filter_wd = "Sæt filter (kun når én ugedag er valgt): ufundne, der mangler den ugedag",
  f_type = "Cache-type",
  all_types = "Alle typer",
  f_filter_type = "Sæt filter (kun når én type er valgt)",
  f_start = "Startdato",
  f_days = "Antal dage",
  f_filter_ct = "Sæt filter: ufundne, der mangler ugedag",
  no_filter = "Intet filter",
  f_attr = "Attribut",
  f_datekind = "Datotype",
  f_ignore_own = "Ignorér egne fund (vis kun mulighederne)",
  f_filter_attr = "Sæt filter (kun når én attribut er valgt)",
  m_month = "Måneds Matrix", m_streak = "Streak Matrix", m_weekday = "Ugedage Matrix",
  m_types = "D/T pr. cache-type", m_missing = "Manglende cache-typer", m_year = "Årskalender pr. type",
  m_attrm = "Attribut Matrix", m_attrc = "Attribut Kalender", m_corr = "Corrected → noter",
  m_import = "Importér PQ", m_config = "Indstillinger", m_help = "Hjælp", m_close = "Luk",
  menu_status = "Fundne: %s   ·   Ufundne: %s   ·   Radius: %s",
  radius_none = "ingen",
  error_msg = "Der opstod en fejl i '%s':\n%s",
  help_title = "%s – hjælp",
  help1 = "<h2>Rapporterne</h2><ul>"
    .. "<li><b>Måneds Matrix</b> – D/T-kombinationer for en valgt måned. Grøn: fundet i måneden (alle år). Rød: mangler, med antal af årets 12 måneder der mangler og antal ufundne muligheder.</li>"
    .. "<li><b>Streak Matrix</b> – for hver kombination, hvor mange af årets 12 måneder du mangler.</li>"
    .. "<li><b>Ugedage Matrix</b> – D/T-matrix for hver ugedag (mandag–søndag).</li>"
    .. "<li><b>Type Matrix</b> – D/T-matrix pr. cache-type.</li>"
    .. "<li><b>Manglende cache-typer</b> – hvilke typer du mangler de næste dage, pr. ugedag og pr. dag i måneden, samt manglende D/T pr. ugedag og dag.</li>"
    .. "<li><b>Årskalender</b> – alle årets datoer for én cache-type: fundet eller mangler.</li>"
    .. "<li><b>Attribut Matrix</b> og <b>Attribut Kalender</b> – D/T og datoer pr. attribut. Kalenderen kan tælle efter fundet dato eller <i>placed date</i> (datoen cachen blev lagt ud).</li>"
    .. "<li><b>Corrected → noter</b> – skriver linjen <code>~*Corrected: N.. E..*~</code> i cachens note og opdaterer den, hvis den findes.</li>"
    .. "<li><b>Importér PQ</b> – importerer zip-filerne i PQ-mappen og rydder op efter dit valg.</li></ul>",
  help2 = "<h2>Filter</h2><p>De fleste rapporter kan sætte et filter i OpenSAK med de ufundne caches, der matcher rapporten. "
    .. "Filteret sættes i databasen med de ufundne caches (Indstillinger).</p>",
  help3 = "<h2>Indstillinger</h2><p>Radius måles fra det aktive centerpunkt (centerpunktet vælges i OpenSAK's værktøjslinje). "
    .. "Står radius på 0, tælles alle ufundne caches. Fundne og ufundne caches kan ligge i samme database eller i hver sin.</p>",
  help4 = "<h2>Begrænsninger</h2><p>OpenSAK's makroer kan ikke hente mails fra Gmail og kan ikke flytte filer til Windows' papirkurv. "
    .. "Brug <code>GetPQ.ps1</code> til at hente PQ'erne ned i PQ-mappen; zip-filerne kan derefter importeres her og flyttes til en undermappe. "
    .. "OpenSAK lader en makro åbne højst 5 filer pr. kørsel.</p>",
}

STR.en = {
  title = "GC Macros",
  active_db = "(active database)",
  footer = "Made by GC Macros (OpenSAK Lua) ",
  open_limit = "The report is saved here (OpenSAK opens at most 5 files per run – open it yourself, or run the macro again):\n%s",
  open_fail = "The report is saved here but could not be opened automatically:\n%s\n(%s)",
  within = "within %s km",
  total_word = "in total",
  filter_none = "No unfound caches match – the filter is unchanged.",
  months = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" },
  months_short = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" },
  weekdays = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" },
  weekdays_short = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" },
  weekdays_2 = { "Mo", "Tu", "We", "Th", "Fr", "Sa", "Su" },
  after_opts = { "Keep the zip files", "Move to the subfolder 'imported'", "Delete the zip files" },
  imported_dir = "imported",
  date_kinds = { "Found date", "Placed date" },
  streak_modes = { "No filter", "Set filter: combinations missing months",
                   "Set filter: completed combinations (safe streak caches)" },
  cfg_title = "%s – Settings",
  centre_label = "Centre point (chosen in the toolbar): %s",
  centre_coords = "coordinates",
  centre_none = "not set",
  f_found_db = "Database with found caches",
  f_unfound_db = "Database with unfound caches",
  f_import_db = "Database for PQ import",
  f_radius = "Radius from centre point (0 = none)",
  f_pq_folder = "Folder with PQ zip files",
  f_after = "After import",
  f_lang = "Sprog / Language",
  subtitle_found = "Found: %s",
  tile_missing = "missing",
  tile_finds_total = "finds in total",
  col_weekday = "Weekday",
  col_found = "Found",
  col_missing = "Missing",
  col_type = "Type",
  col_date = "Date",
  month_title = "Month Matrix – %s",
  found_in_month = "found in %s",
  of12_missing = "of 12 months missing",
  banner_month = "🎉 Congratulations! You have found every D/T combination in %s 🎉",
  tile_combos_month = "combinations found in %s",
  tile_possible = "missing, but with unfound candidates (%s)",
  note_month = "Green: number of finds in %s. Red: how many of the year's 12 months the combination is missing, and how many unfound caches exist (%s). Grey: no unfound candidates.",
  streak_all12 = "all 12 months",
  streak_months_missing = "months missing",
  tile_complete = "completed combinations (all 12 months)",
  tile_months_missing_total = "months missing in total",
  note_streak = "The number in a red cell is how many months (out of 12) you have not yet found a cache with that D/T combination. The second number is unfound caches with the combination (%s).",
  wd_title = "Weekday Matrix",
  wd_finds = "found",
  wd_missing_cell = "missing",
  combos_heading = "%s – %d / 81 combinations found",
  tm_title = "D/T matrix per cache type",
  unfound_cell = "unfound %s",
  ct_title = "Missing cache types",
  ct_next_days = "The next %d days",
  ct_note = "✓ = you have found that type on that date (in any year).",
  tile_days_shown = "dates shown",
  tile_types_missing = "types missing in the period",
  ct_by_weekday = "Cache types per weekday",
  ct_by_dom = "Cache types per day of the month",
  ct_dt_wd = "D/T combinations per weekday – missing",
  ct_dt_dom = "D/T combinations per day of the month – missing",
  n_missing = "%d missing",
  none_missing = "No missing combinations",
  dom_summary = "Day %d – %d missing",
  yc_title = "Year calendar – %s",
  tile_dates_with = "dates with a find of the type",
  tile_dates_missing = "dates missing",
  yc_note = "Green = you have found the type on that date (in any year). Red = missing. Gold outline = today.",
  all_pos = "All positive attributes",
  all_neg = "All negative attributes",
  attr_fallback = "attribute %s",
  ac_title = "Attribute Calendar – %s",
  ac_placed_note = " · placed date = the date the cache was hidden (counts your finds)",
  col_attribute = "Attribute",
  col_days_covered = "Dates covered",
  col_days_missing = "Dates missing",
  col_total_finds = "Total finds",
  am_title = "Attribute Matrix",
  col_dt_found = "D/T found",
  col_dt_poss = "D/T with candidates",
  no_attrs = "There are no attributes on your finds in the database.",
  corr_prompt = "Which caches should get their corrected coordinates written to the note?",
  corr_scopes = { "The selected cache", "All caches in the shown list", "The whole database" },
  corr_none_selected = "No cache is selected in the list.",
  corr_no_coords = "None of the caches has corrected coordinates.",
  corr_all_done = "All %d notes are already up to date.",
  corr_confirm = "%d notes will get the line ~*Corrected: …*~ (of %d caches with corrected coordinates). Continue?",
  corr_done = "%d notes updated.",
  imp_no_folder = "The PQ folder does not exist: %s\nChoose it under Settings.",
  imp_no_zips = "There are no zip files in %s.\nFetch the PQs first (e.g. with GetPQ.ps1) – OpenSAK macros cannot fetch mail from Gmail.",
  imp_confirm = "%d zip files in %s will be imported into the database '%s'. After the import: %s.\nContinue?",
  imp_failed = "The import did not complete correctly – the zip files were not touched. See the macro output.",
  imp_done = "Import finished: %d new and %d updated caches.",
  f_month = "Month",
  f_filter_month = "Set a filter in OpenSAK afterwards (unfound caches missing in the month)",
  f_filter = "Filter",
  f_weekday = "Weekday",
  all_weekdays = "All weekdays",
  f_filter_wd = "Set filter (only when one weekday is chosen): unfound caches missing that weekday",
  f_type = "Cache type",
  all_types = "All types",
  f_filter_type = "Set filter (only when one type is chosen)",
  f_start = "Start date",
  f_days = "Number of days",
  f_filter_ct = "Set filter: unfound caches missing weekday",
  no_filter = "No filter",
  f_attr = "Attribute",
  f_datekind = "Date type",
  f_ignore_own = "Ignore own finds (show only the candidates)",
  f_filter_attr = "Set filter (only when one attribute is chosen)",
  m_month = "Month Matrix", m_streak = "Streak Matrix", m_weekday = "Weekday Matrix",
  m_types = "D/T per cache type", m_missing = "Missing cache types", m_year = "Year calendar per type",
  m_attrm = "Attribute Matrix", m_attrc = "Attribute Calendar", m_corr = "Corrected → notes",
  m_import = "Import PQ", m_config = "Settings", m_help = "Help", m_close = "Close",
  menu_status = "Found: %s   ·   Unfound: %s   ·   Radius: %s",
  radius_none = "none",
  error_msg = "An error occurred in '%s':\n%s",
  help_title = "%s – help",
  help1 = "<h2>The reports</h2><ul>"
    .. "<li><b>Month Matrix</b> – D/T combinations for a chosen month. Green: found in the month (any year). Red: missing, with how many of the year's 12 months are missing and how many unfound candidates exist.</li>"
    .. "<li><b>Streak Matrix</b> – for every combination, how many of the year's 12 months you are missing.</li>"
    .. "<li><b>Weekday Matrix</b> – a D/T matrix for each weekday (Monday–Sunday).</li>"
    .. "<li><b>Type Matrix</b> – a D/T matrix per cache type.</li>"
    .. "<li><b>Missing cache types</b> – which types you are missing in the coming days, per weekday and per day of the month, plus the missing D/T combinations per weekday and day.</li>"
    .. "<li><b>Year calendar</b> – every date of the year for one cache type: found or missing.</li>"
    .. "<li><b>Attribute Matrix</b> and <b>Attribute Calendar</b> – D/T and dates per attribute. The calendar can count by found date or by <i>placed date</i> (the date the cache was hidden).</li>"
    .. "<li><b>Corrected → notes</b> – writes the line <code>~*Corrected: N.. E..*~</code> into the cache's note, and updates it if it exists.</li>"
    .. "<li><b>Import PQ</b> – imports the zip files in the PQ folder and tidies up as you choose.</li></ul>",
  help2 = "<h2>Filter</h2><p>Most reports can set a filter in OpenSAK with the unfound caches that match the report. "
    .. "The filter is set in the database holding the unfound caches (Settings).</p>",
  help3 = "<h2>Settings</h2><p>The radius is measured from the active centre point (chosen in OpenSAK's toolbar). "
    .. "With radius 0 all unfound caches are counted. Found and unfound caches can be in the same database or in separate ones.</p>",
  help4 = "<h2>Limitations</h2><p>OpenSAK macros cannot fetch mail from Gmail and cannot move files to the Windows recycle bin. "
    .. "Use <code>GetPQ.ps1</code> to download the PQs into the PQ folder; the zip files can then be imported here and moved to a subfolder. "
    .. "OpenSAK lets a macro open at most 5 files per run.</p>",
}

-- ── Language state ───────────────────────────────────────────────────────
local LANG = DEFAULT_LANG
local TITLE = STR[LANG].title

local function T(k, ...)
  local s = (STR[LANG] and STR[LANG][k]) or STR.da[k] or k
  if select("#", ...) > 0 then return string.format(s, ...) end
  return s
end

-- Lists that the code indexes directly; refilled in place when the language changes.
local MONTHS, MONTHS_SHORT, WEEKDAYS, WEEKDAYS_SHORT, WEEKDAYS_2 = {}, {}, {}, {}, {}
local AFTER_IMPORT, DATE_KINDS, STREAK_MODES, CORR_SCOPES = {}, {}, {}, {}
local ALL_POS, ALL_NEG = "", ""

local function fill(dst, src)
  for i = #dst, 1, -1 do dst[i] = nil end
  for i, v in ipairs(src) do dst[i] = v end
end

local function apply_lang(l)
  if not STR[l] then l = "da" end
  LANG = l
  TITLE = STR[l].title
  fill(MONTHS, STR[l].months); fill(MONTHS_SHORT, STR[l].months_short)
  fill(WEEKDAYS, STR[l].weekdays); fill(WEEKDAYS_SHORT, STR[l].weekdays_short); fill(WEEKDAYS_2, STR[l].weekdays_2)
  fill(AFTER_IMPORT, STR[l].after_opts); fill(DATE_KINDS, STR[l].date_kinds)
  fill(STREAK_MODES, STR[l].streak_modes); fill(CORR_SCOPES, STR[l].corr_scopes)
  ALL_POS, ALL_NEG = STR[l].all_pos, STR[l].all_neg
end
apply_lang(DEFAULT_LANG)

local esc = opensak.html.escape


-- ── Fixed lists ──────────────────────────────────────────────────────────
local RATINGS = { 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5 }
local DAYS_IN_MONTH = { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }

-- The nine cache types of GC_Menu (name = what OpenSAK stores in the database).
local TYPES = {
  { name = "Traditional Cache",         label = "Traditional" },
  { name = "Multi-cache",               label = "Multi" },
  { name = "Unknown Cache",             label = "Unknown" },
  { name = "Event Cache",               label = "Event" },
  { name = "Virtual Cache",             label = "Virtual" },
  { name = "Wherigo Cache",             label = "Wherigo" },
  { name = "Earthcache",                label = "EarthCache" },
  { name = "Letterbox Hybrid",          label = "Letterbox" },
  { name = "Cache In Trash Out Event",  label = "CITO" },
}
local TYPE_INDEX = {}
for i, t in ipairs(TYPES) do TYPE_INDEX[opensak.text.lower(t.name)] = i end
local function type_index(name)
  if not name then return nil end
  return TYPE_INDEX[opensak.text.lower(name)]
end

-- ── Small helpers ────────────────────────────────────────────────────────
local function key(d, t) return string.format("%.1f:%.1f", d, t) end
local function r1(x) return string.format("%.1f", x) end

local function index_of(list, value)
  for i, v in ipairs(list) do if v == value then return i end end
  return nil
end

-- Monday = 1 … Sunday = 7 for a date "YYYY-MM-DD".
local function weekday_of(ds)
  local y, m, d = ds:match("^(%d+)-(%d+)-(%d+)")
  local w = tonumber(os.date("%w", os.time{ year = tonumber(y), month = tonumber(m), day = tonumber(d), hour = 12 }))
  return (w + 6) % 7 + 1
end

local function today()
  local t = os.date("*t")
  return t.year, t.month, t.day
end

local function dbo(name)
  if name and name ~= "" and name ~= opensak.database() then return { database = name } end
  return nil
end

local function fmt_km(km) return string.format("%.0f", km) end

-- ── Settings ─────────────────────────────────────────────────────────────
local function load_cfg()
  local s = opensak.settings.load()
  s.found_db = s.found_db or ""        -- "" = the active database
  s.unfound_db = s.unfound_db or ""
  s.import_db = s.import_db or ""
  s.radius = s.radius or 50
  s.pq_folder = s.pq_folder or "C:/pqfiler"
  if type(s.pq_after) ~= "number" or s.pq_after < 1 or s.pq_after > 3 then s.pq_after = 2 end
  s.lang = s.lang or DEFAULT_LANG
  apply_lang(s.lang)
  return s
end

local function save_cfg(cfg) opensak.settings.save(cfg) end

local function db_names()
  local names = { T("active_db") }
  for _, d in ipairs(opensak.databases()) do names[#names + 1] = d.name end
  return names
end

local function db_value(v) if v == T("active_db") then return "" end return v end
local function db_default(v, names) if v ~= "" and index_of(names, v) then return v end return names[1] end

local LANG_NAMES = { da = "Dansk", en = "English" }

local function edit_settings(cfg)
  local names = db_names()
  local c = opensak.center()
  local centre_text = (c and c.lat)
      and ((c.name ~= "" and c.name or T("centre_coords")) .. " (" .. opensak.coords.format(c.lat, c.lon) .. ")")
      or T("centre_none")
  local v = opensak.form{
    title = T("cfg_title", TITLE),
    fields = {
      { type = "label", label = T("centre_label", centre_text), bold = true },
      { type = "choice", id = "found_db", label = T("f_found_db"), options = names,
        default = db_default(cfg.found_db, names) },
      { type = "choice", id = "unfound_db", label = T("f_unfound_db"), options = names,
        default = db_default(cfg.unfound_db, names) },
      { type = "choice", id = "import_db", label = T("f_import_db"), options = names,
        default = db_default(cfg.import_db, names) },
      { type = "number", id = "radius", label = T("f_radius"), default = cfg.radius,
        min = 0, max = 20000, decimals = 0, suffix = " km" },
      { type = "folder", id = "pq_folder", label = T("f_pq_folder"), default = cfg.pq_folder },
      { type = "choice", id = "pq_after", label = T("f_after"), options = AFTER_IMPORT, default = AFTER_IMPORT[cfg.pq_after] },
      { type = "choice", id = "lang", label = T("f_lang"), options = { LANG_NAMES.da, LANG_NAMES.en },
        default = LANG_NAMES[cfg.lang] or LANG_NAMES.da },
    },
  }
  if not v then return end
  cfg.found_db = db_value(v.found_db)
  cfg.unfound_db = db_value(v.unfound_db)
  cfg.import_db = db_value(v.import_db)
  cfg.radius = v.radius or 0
  cfg.pq_folder = v.pq_folder or cfg.pq_folder
  cfg.pq_after = index_of(AFTER_IMPORT, v.pq_after) or cfg.pq_after
  cfg.lang = (v.lang == LANG_NAMES.en) and "en" or "da"
  apply_lang(cfg.lang)
  save_cfg(cfg)
end

-- ── Data ─────────────────────────────────────────────────────────────────
-- Your finds: one table per cache with D/T key, month, day and weekday.
local function load_finds(cfg)
  local out = {}
  for r in opensak.sql_each([[
      SELECT gc_code AS code, cache_type AS typ, difficulty AS d, terrain AS t,
             substr(found_date, 1, 10) AS fd, substr(hidden_date, 1, 10) AS pd
      FROM caches
      WHERE found = 1 AND found_date IS NOT NULL AND parent_gc_code IS NULL]],
      nil, dbo(cfg.found_db)) do
    if r.d and r.t and r.fd and #r.fd == 10 then
      r.key = key(r.d, r.t)
      r.month = tonumber(r.fd:sub(6, 7))
      r.day = tonumber(r.fd:sub(9, 10))
      r.wd = weekday_of(r.fd)
      r.ti = type_index(r.typ)
      out[#out + 1] = r
    end
  end
  return out
end

-- Unfound, non-archived caches that are not your own – within the radius, if set.
local function load_unfound(cfg)
  local spec = { found = false, owned = false, archived = false,
                 fields = { "type", "difficulty", "terrain", "lat", "lon" } }
  if cfg.unfound_db and cfg.unfound_db ~= "" and cfg.unfound_db ~= opensak.database() then
    spec.database = cfg.unfound_db
  end
  local c = opensak.center()
  if (cfg.radius or 0) > 0 and c and c.lat then
    spec.near = { lat = c.lat, lon = c.lon, km = cfg.radius }
  end
  local out = {}
  for u in opensak.caches(spec) do
    if u.difficulty and u.terrain then
      out[#out + 1] = { code = u.code, typ = u.type, ti = type_index(u.type), d = u.difficulty,
                        t = u.terrain, key = key(u.difficulty, u.terrain), lat = u.lat, lon = u.lon }
    end
  end
  return out
end

local function radius_text(cfg)
  local c = opensak.center()
  if (cfg.radius or 0) > 0 and c and c.lat then return T("within", fmt_km(cfg.radius)) end
  return T("total_word")
end

local function found_name(cfg) return cfg.found_db ~= "" and cfg.found_db or opensak.database() end

-- Set a filter in the database with the unfound caches: only those accept() approves.
local function set_filter(cfg, unfound, accept)
  if cfg.unfound_db and cfg.unfound_db ~= "" and cfg.unfound_db ~= opensak.database() then
    opensak.switch_database(cfg.unfound_db)
  end
  local codes = {}
  for _, u in ipairs(unfound) do
    if accept(u) then codes[#codes + 1] = u.code end
  end
  if #codes == 0 then
    opensak.message(T("filter_none"), TITLE)
    return 0
  end
  return opensak.filter{ codes = codes, label = TITLE }
end

-- ── HTML ─────────────────────────────────────────────────────────────────
local CSS = [[
table.dt { border-collapse: collapse; margin: 14px auto; }
table.dt th { padding: 6px 10px; font-size: .85em; opacity: .85; }
table.dt td { min-width: 78px; height: 62px; text-align: center; vertical-align: middle;
              border: 2px solid transparent; border-radius: 6px; font-size: .8em; padding: 2px 4px; }
td.ok   { background: rgba(46, 204, 113, .32); }
td.miss { background: rgba(231, 76, 60, .32); }
td.none { background: rgba(127, 127, 127, .20); }
td.today, th.today { outline: 2px solid #e0b030; }
.big { display: block; font-size: 1.5em; font-weight: bold; line-height: 1.1; }
.sub { display: block; font-size: .78em; opacity: .85; }
.banner { text-align: center; border: 2px solid #e0b030; border-radius: 10px; padding: 14px;
          margin: 16px 0; font-size: 1.15em; background: rgba(224, 176, 48, .16); }
table.cal { border-collapse: collapse; margin: 10px 0; }
table.cal td, table.cal th { text-align: center; padding: 3px 5px; font-size: .78em; min-width: 22px; }
td.na { opacity: .25; }
.months { display: flex; flex-wrap: wrap; gap: 18px; justify-content: center; }
.months .m { min-width: 210px; }
.months h3 { text-align: center; margin: 4px 0; }
details { margin: 6px 0; }
.note { opacity: .75; font-size: .85em; margin: 6px 0; }
]]

-- D × T table; cellfn(d, t) returns class, content and an optional tooltip.
local function build_grid(cellfn)
  local h = { "<table class='dt'><tr><th>D \\ T</th>" }
  for _, t in ipairs(RATINGS) do h[#h + 1] = "<th>T " .. r1(t) .. "</th>" end
  h[#h + 1] = "</tr>"
  for _, d in ipairs(RATINGS) do
    h[#h + 1] = "<tr><th>D " .. r1(d) .. "</th>"
    for _, t in ipairs(RATINGS) do
      local cls, inner, tip = cellfn(d, t)
      h[#h + 1] = "<td class='" .. cls .. "'" .. (tip and (" title='" .. esc(tip) .. "'") or "") .. ">"
                  .. inner .. "</td>"
    end
    h[#h + 1] = "</tr>"
  end
  h[#h + 1] = "</table>"
  return table.concat(h)
end

local function big(n, sub, sub2)
  return "<span class='big'>" .. n .. "</span><span class='sub'>" .. sub .. "</span>"
         .. (sub2 and ("<span class='sub'>" .. sub2 .. "</span>") or "")
end

-- OpenSAK lets a macro open at most 5 files per run. After that the file's location is shown instead.
local opened_files = 0
local function open_report(path)
  if opened_files >= 5 then
    opensak.message(T("open_limit", path), TITLE)
    return
  end
  opened_files = opened_files + 1
  local ok, err = pcall(opensak.open, path)
  if not ok then
    opensak.message(T("open_fail", path, tostring(err)), TITLE)
  end
end

local function publish(file, title, subtitle, parts)
  local spec = { title = title, subtitle = subtitle, css = CSS,
                 footer = T("footer") .. os.date("%Y-%m-%d %H:%M") }
  for _, p in ipairs(parts) do spec[#spec + 1] = p end
  local path = opensak.write_text(opensak.temp_dir() .. "/" .. file, opensak.html.page(spec))
  print(title .. " → " .. path)
  open_report(path)
  return path
end

local function count_keys(set) local n = 0 for _ in pairs(set or {}) do n = n + 1 end return n end


-- ══════════════════════════════════════════════════════════════════════════
--  MONTH MATRIX
-- ══════════════════════════════════════════════════════════════════════════
-- D/T combinations for one month: green = found in the month (any year), red = missing,
-- with how many of the 12 months are missing and how many unfound candidates exist.
local function report_month(cfg, month, filter_on)
  local finds = load_finds(cfg)
  local in_month, months = {}, {}
  for _, f in ipairs(finds) do
    months[f.key] = months[f.key] or {}
    months[f.key][f.month] = true
    if f.month == month then in_month[f.key] = (in_month[f.key] or 0) + 1 end
  end
  local unfound = load_unfound(cfg)
  local near = {}
  for _, u in ipairs(unfound) do near[u.key] = (near[u.key] or 0) + 1 end

  local where = radius_text(cfg)
  local mname = MONTHS[month]
  local have, missing, possible = 0, 0, 0
  local grid = build_grid(function(d, t)
    local k = key(d, t)
    if in_month[k] then
      have = have + 1
      return "ok", big(in_month[k], T("found_in_month", (LANG == "da") and opensak.text.lower(mname) or mname))
    end
    missing = missing + 1
    local n = near[k] or 0
    if n > 0 then possible = possible + 1 end
    return (n > 0) and "miss" or "none",
           big(12 - count_keys(months[k]), T("of12_missing"), n .. " " .. where),
           "D " .. r1(d) .. " / T " .. r1(t)
  end)

  local _, cur_month = today()
  local complete = (have == 81)
  local parts = {}
  if complete and month == cur_month then
    parts[#parts + 1] = "<div class='banner'>" .. T("banner_month", mname) .. "</div>"
  end
  parts[#parts + 1] = opensak.html.tiles{
    { label = T("tile_combos_month", mname), value = have .. " / 81" },
    { label = T("tile_missing"), value = missing },
    { label = T("tile_possible", where), value = possible },
    { label = T("tile_finds_total"), value = #finds },
  }
  parts[#parts + 1] = grid
  parts[#parts + 1] = "<p class='note'>" .. T("note_month", mname, where) .. "</p>"
  publish("gc_month_matrix.html", T("month_title", mname), T("subtitle_found", found_name(cfg)), parts)

  if filter_on then
    if complete and month == cur_month then
      -- The month is complete: show the safe streak caches instead (combinations found in all 12 months).
      set_filter(cfg, unfound, function(u) return count_keys(months[u.key]) == 12 end)
    else
      set_filter(cfg, unfound, function(u) return not in_month[u.key] end)
    end
  end
end

-- ══════════════════════════════════════════════════════════════════════════
--  STREAK MATRIX
-- ══════════════════════════════════════════════════════════════════════════
-- For every D/T combination: how many of the year's 12 months you are missing.
-- mode: 0 = no filter, 1 = combinations missing months, 2 = completed combinations (safe streak caches).
local function report_streak(cfg, mode)
  local finds = load_finds(cfg)
  local months = {}
  for _, f in ipairs(finds) do
    months[f.key] = months[f.key] or {}
    months[f.key][f.month] = true
  end
  local unfound = load_unfound(cfg)
  local near = {}
  for _, u in ipairs(unfound) do near[u.key] = (near[u.key] or 0) + 1 end

  local where = radius_text(cfg)
  local complete, months_missing = 0, 0
  local grid = build_grid(function(d, t)
    local k = key(d, t)
    local n = count_keys(months[k])
    if n == 12 then
      complete = complete + 1
      return "ok", big("✓", T("streak_all12"))
    end
    months_missing = months_missing + (12 - n)
    local p = near[k] or 0
    return (p > 0) and "miss" or "none", big(12 - n, T("streak_months_missing"), p .. " " .. where),
           "D " .. r1(d) .. " / T " .. r1(t)
  end)

  publish("gc_streak_matrix.html", "Streak Matrix", T("subtitle_found", found_name(cfg)), {
    opensak.html.tiles{
      { label = T("tile_complete"), value = complete .. " / 81" },
      { label = T("tile_months_missing_total"), value = months_missing },
      { label = T("tile_finds_total"), value = #finds },
    },
    grid,
    "<p class='note'>" .. T("note_streak", where) .. "</p>",
  })

  if mode == 1 then
    set_filter(cfg, unfound, function(u) return count_keys(months[u.key]) < 12 end)
  elseif mode == 2 then
    set_filter(cfg, unfound, function(u) return count_keys(months[u.key]) == 12 end)
  end
end

-- ══════════════════════════════════════════════════════════════════════════
--  WEEKDAY MATRIX
-- ══════════════════════════════════════════════════════════════════════════
-- which: 0 = all weekdays, 1–7 = Monday–Sunday. filter_on only works for one weekday.
local function report_weekdays(cfg, which, filter_on)
  local finds = load_finds(cfg)
  local found = {}
  for w = 1, 7 do found[w] = {} end
  for _, f in ipairs(finds) do found[f.wd][f.key] = (found[f.wd][f.key] or 0) + 1 end
  local unfound = load_unfound(cfg)
  local near = {}
  for _, u in ipairs(unfound) do near[u.key] = (near[u.key] or 0) + 1 end

  local where = radius_text(cfg)
  local list = {}
  if which == 0 then for w = 1, 7 do list[#list + 1] = w end else list[1] = which end

  local parts, summary = {}, {}
  for _, w in ipairs(list) do
    local have = 0
    local grid = build_grid(function(d, t)
      local k = key(d, t)
      if found[w][k] then
        have = have + 1
        return "ok", big(found[w][k], T("wd_finds"))
      end
      local n = near[k] or 0
      return (n > 0) and "miss" or "none", big("–", T("wd_missing_cell"), n .. " " .. where), "D " .. r1(d) .. " / T " .. r1(t)
    end)
    summary[#summary + 1] = { day = WEEKDAYS[w], have = have, missing = 81 - have }
    parts[#parts + 1] = "<h2>" .. T("combos_heading", WEEKDAYS[w], have) .. "</h2>" .. grid
  end

  table.insert(parts, 1, opensak.html.table(summary, {
    columns = { { "day", T("col_weekday") }, { "have", T("col_found") }, { "missing", T("col_missing") } },
    bars = { "have" } }))
  publish("gc_weekday_matrix.html", T("wd_title"), T("subtitle_found", found_name(cfg)), parts)

  if filter_on and which ~= 0 then
    set_filter(cfg, unfound, function(u) return not found[which][u.key] end)
  end
end

-- ══════════════════════════════════════════════════════════════════════════
--  TYPE MATRIX
-- ══════════════════════════════════════════════════════════════════════════
-- which: 0 = all types, otherwise the number in TYPES. filter_on only works for one type.
local function report_type_matrix(cfg, which, filter_on)
  local finds = load_finds(cfg)
  local found = {}
  for i = 1, #TYPES do found[i] = {} end
  for _, f in ipairs(finds) do
    if f.ti then found[f.ti][f.key] = (found[f.ti][f.key] or 0) + 1 end
  end
  local unfound = load_unfound(cfg)
  local near = {}
  for i = 1, #TYPES do near[i] = {} end
  for _, u in ipairs(unfound) do
    if u.ti then near[u.ti][u.key] = (near[u.ti][u.key] or 0) + 1 end
  end

  local where = radius_text(cfg)
  local list = {}
  if which == 0 then for i = 1, #TYPES do list[#list + 1] = i end else list[1] = which end

  local parts, summary = {}, {}
  for _, ti in ipairs(list) do
    local have = 0
    local grid = build_grid(function(d, t)
      local k = key(d, t)
      if found[ti][k] then
        have = have + 1
        return "ok", big(found[ti][k], T("wd_finds"))
      end
      local n = near[ti][k] or 0
      return (n > 0) and "miss" or "none", big(n, T("unfound_cell", where)), "D " .. r1(d) .. " / T " .. r1(t)
    end)
    summary[#summary + 1] = { typ = TYPES[ti].label, have = have, missing = 81 - have }
    parts[#parts + 1] = "<h2>" .. T("combos_heading", esc(TYPES[ti].label), have) .. "</h2>" .. grid
  end
  table.insert(parts, 1, opensak.html.table(summary, {
    columns = { { "typ", T("col_type") }, { "have", T("col_found") }, { "missing", T("col_missing") } },
    bars = { "have" } }))
  publish("gc_type_matrix.html", T("tm_title"), T("subtitle_found", found_name(cfg)), parts)

  if filter_on and which ~= 0 then
    set_filter(cfg, unfound, function(u) return u.ti == which and not found[which][u.key] end)
  end
end


-- ══════════════════════════════════════════════════════════════════════════
--  MISSING CACHE TYPES (date, weekday, day of month, D/T per weekday and day)
-- ══════════════════════════════════════════════════════════════════════════
local function ymd(ds)
  local y, m, d = ds:match("^(%d+)-(%d+)-(%d+)")
  return tonumber(y), tonumber(m), tonumber(d)
end

-- Missing D/T combinations in a set: count and text "1.0/4.0, 2.5/3.0".
local function dt_missing(set)
  local parts, n = {}, 0
  for _, d in ipairs(RATINGS) do
    for _, t in ipairs(RATINGS) do
      if not set[key(d, t)] then
        n = n + 1
        parts[#parts + 1] = r1(d) .. "/" .. r1(t)
      end
    end
  end
  return n, table.concat(parts, ", ")
end

local function mark(found) return found and "✓" or "✗" end

-- wd_filter: 0 = no filter, 1–7 = set a filter for unfound caches missing that weekday.
local function report_cache_types(cfg, start_ds, ndays, wd_filter)
  local finds = load_finds(cfg)
  local by_md, by_wd, by_dom, dt_wd, dt_dom = {}, {}, {}, {}, {}
  for w = 1, 7 do by_wd[w] = {}; dt_wd[w] = {} end
  for d = 1, 31 do by_dom[d] = {}; dt_dom[d] = {} end
  for _, f in ipairs(finds) do
    local md = string.format("%02d-%02d", f.month, f.day)
    by_md[md] = by_md[md] or {}
    if f.ti then
      by_md[md][f.ti] = true
      by_wd[f.wd][f.ti] = true
      by_dom[f.day][f.ti] = true
    end
    dt_wd[f.wd][f.key] = true
    dt_dom[f.day][f.key] = true
  end

  local ty, tm, td = today()
  local today_ds = string.format("%04d-%02d-%02d", ty, tm, td)
  local today_wd = weekday_of(today_ds)
  local parts = {}

  -- 1) Day by day
  local sy, sm, sd = ymd(start_ds)
  local base = os.time{ year = sy, month = sm, day = sd, hour = 12 }
  local h = { "<h2>" .. T("ct_next_days", ndays) .. "</h2><table class='cal'><tr><th>" .. T("col_date") .. "</th><th>"
              .. T("col_weekday") .. "</th>" }
  for _, t in ipairs(TYPES) do h[#h + 1] = "<th>" .. esc(t.label) .. "</th>" end
  h[#h + 1] = "</tr>"
  local missing_total = 0
  for i = 0, ndays - 1 do
    local ds = os.date("%Y-%m-%d", base + i * 86400)
    local md = ds:sub(6)
    h[#h + 1] = "<tr><td>" .. ds:sub(9, 10) .. "." .. ds:sub(6, 7) .. "</td><td>" .. WEEKDAYS_SHORT[weekday_of(ds)] .. "</td>"
    for ti = 1, #TYPES do
      local ok = by_md[md] and by_md[md][ti]
      if not ok then missing_total = missing_total + 1 end
      h[#h + 1] = "<td class='" .. (ok and "ok" or "miss") .. (ds == today_ds and " today" or "") .. "'>" .. mark(ok) .. "</td>"
    end
    h[#h + 1] = "</tr>"
  end
  h[#h + 1] = "</table><p class='note'>" .. T("ct_note") .. "</p>"
  parts[#parts + 1] = opensak.html.tiles{ { label = T("tile_days_shown"), value = ndays },
                                           { label = T("tile_types_missing"), value = missing_total } }
  parts[#parts + 1] = table.concat(h)

  -- 2) Cache types per weekday
  h = { "<h2>" .. T("ct_by_weekday") .. "</h2><table class='cal'><tr><th></th>" }
  for w = 1, 7 do h[#h + 1] = "<th" .. (w == today_wd and " class='today'" or "") .. ">" .. WEEKDAYS_SHORT[w] .. "</th>" end
  h[#h + 1] = "</tr>"
  for ti, t in ipairs(TYPES) do
    h[#h + 1] = "<tr><th>" .. esc(t.label) .. "</th>"
    for w = 1, 7 do
      h[#h + 1] = "<td class='" .. (by_wd[w][ti] and "ok" or "miss") .. (w == today_wd and " today" or "") .. "'>" .. mark(by_wd[w][ti]) .. "</td>"
    end
    h[#h + 1] = "</tr>"
  end
  h[#h + 1] = "</table>"
  parts[#parts + 1] = table.concat(h)

  -- 3) Cache types per day of the month
  h = { "<h2>" .. T("ct_by_dom") .. "</h2><table class='cal'><tr><th></th>" }
  for d = 1, 31 do h[#h + 1] = "<th" .. (d == td and " class='today'" or "") .. ">" .. d .. "</th>" end
  h[#h + 1] = "</tr>"
  for ti, t in ipairs(TYPES) do
    h[#h + 1] = "<tr><th>" .. esc(t.label) .. "</th>"
    for d = 1, 31 do
      h[#h + 1] = "<td class='" .. (by_dom[d][ti] and "ok" or "miss") .. (d == td and " today" or "") .. "'>" .. mark(by_dom[d][ti]) .. "</td>"
    end
    h[#h + 1] = "</tr>"
  end
  h[#h + 1] = "</table>"
  parts[#parts + 1] = table.concat(h)

  -- 4) D/T per weekday: what is missing
  h = { "<h2>" .. T("ct_dt_wd") .. "</h2><table class='cal'><tr><th></th>" }
  local lists = {}
  for w = 1, 7 do h[#h + 1] = "<th" .. (w == today_wd and " class='today'" or "") .. ">" .. WEEKDAYS_SHORT[w] .. "</th>" end
  h[#h + 1] = "</tr><tr><th>" .. T("col_missing") .. "</th>"
  for w = 1, 7 do
    local n, text = dt_missing(dt_wd[w])
    lists[w] = { n = n, text = text }
    h[#h + 1] = "<td class='" .. (n == 0 and "ok" or "miss") .. (w == today_wd and " today" or "") .. "'>" .. n .. "</td>"
  end
  h[#h + 1] = "</tr></table>"
  for w = 1, 7 do
    h[#h + 1] = "<details><summary>" .. WEEKDAYS[w] .. " – " .. T("n_missing", lists[w].n) .. "</summary>"
                .. (lists[w].n == 0 and T("none_missing") or esc(lists[w].text)) .. "</details>"
  end
  parts[#parts + 1] = table.concat(h)

  -- 5) D/T per day of the month: what is missing
  h = { "<h2>" .. T("ct_dt_dom") .. "</h2><table class='cal'><tr><th></th>" }
  for d = 1, 31 do h[#h + 1] = "<th" .. (d == td and " class='today'" or "") .. ">" .. d .. "</th>" end
  h[#h + 1] = "</tr><tr><th>" .. T("col_missing") .. "</th>"
  local dom_lists = {}
  for d = 1, 31 do
    local n, text = dt_missing(dt_dom[d])
    dom_lists[d] = { n = n, text = text }
    h[#h + 1] = "<td class='" .. (n == 0 and "ok" or "miss") .. (d == td and " today" or "") .. "'>" .. n .. "</td>"
  end
  h[#h + 1] = "</tr></table>"
  for d = 1, 31 do
    h[#h + 1] = "<details><summary>" .. T("dom_summary", d, dom_lists[d].n) .. "</summary>"
                .. (dom_lists[d].n == 0 and T("none_missing") or esc(dom_lists[d].text)) .. "</details>"
  end
  parts[#parts + 1] = table.concat(h)

  publish("gc_missing_types.html", T("ct_title"), T("subtitle_found", found_name(cfg)), parts)

  if wd_filter and wd_filter > 0 then
    local unfound = load_unfound(cfg)
    set_filter(cfg, unfound, function(u) return not dt_wd[wd_filter][u.key] end)
  end
end

-- ══════════════════════════════════════════════════════════════════════════
--  YEAR CALENDAR PER CACHE TYPE
-- ══════════════════════════════════════════════════════════════════════════
local function report_year_calendar(cfg, ti)
  local finds = load_finds(cfg)
  local found, have = {}, 0
  for _, f in ipairs(finds) do
    if f.ti == ti then
      local md = string.format("%02d-%02d", f.month, f.day)
      if not found[md] then found[md] = true; have = have + 1 end
    end
  end
  local Y, TM, TD = today()
  local box = {}
  for m = 1, 12 do
    local first = weekday_of(string.format("%04d-%02d-01", Y, m))
    local h = { "<div class='m'><h3>" .. MONTHS[m] .. "</h3><table class='cal'><tr>" }
    for w = 1, 7 do h[#h + 1] = "<th>" .. WEEKDAYS_2[w] .. "</th>" end
    h[#h + 1] = "</tr><tr>"
    local col = 0
    for _ = 1, first - 1 do h[#h + 1] = "<td></td>"; col = col + 1 end
    for d = 1, DAYS_IN_MONTH[m] do
      local md = string.format("%02d-%02d", m, d)
      local cls = found[md] and "ok" or "miss"
      if m == TM and d == TD then cls = cls .. " today" end
      h[#h + 1] = "<td class='" .. cls .. "'>" .. d .. "</td>"
      col = col + 1
      if col == 7 and d < DAYS_IN_MONTH[m] then h[#h + 1] = "</tr><tr>"; col = 0 end
    end
    h[#h + 1] = "</tr></table></div>"
    box[#box + 1] = table.concat(h)
  end
  publish("gc_year_calendar.html", T("yc_title", TYPES[ti].label), T("subtitle_found", found_name(cfg)), {
    opensak.html.tiles{
      { label = T("tile_dates_with"), value = have .. " / 366" },
      { label = T("tile_dates_missing"), value = 366 - have },
    },
    "<div class='months'>" .. table.concat(box) .. "</div>",
    "<p class='note'>" .. T("yc_note") .. "</p>",
  })
end

-- ══════════════════════════════════════════════════════════════════════════
--  ATTRIBUTES
-- ══════════════════════════════════════════════════════════════════════════
-- The attributes on your finds: { aid =, on =, name = }, sorted by name.
local function attribute_choices(cfg)
  local list, seen = {}, {}
  for r in opensak.sql_each([[
      SELECT DISTINCT a.attribute_id AS aid, a.is_on AS on_, a.name AS name
      FROM attributes a JOIN caches c ON c.id = a.cache_id
      WHERE c.found = 1 AND c.parent_gc_code IS NULL]], nil, dbo(cfg.found_db)) do
    local k = r.aid .. (r.on_ == 1 and "+" or "-")
    if not seen[k] then
      seen[k] = true
      list[#list + 1] = { aid = r.aid, on = (r.on_ == 1), name = r.name or T("attr_fallback", r.aid) }
    end
  end
  table.sort(list, function(a, b)
    if a.name ~= b.name then return a.name < b.name end
    return a.on and not b.on
  end)
  return list
end

local function attr_label(a) return (a.on and "✓ " or "✗ ") .. a.name .. " (" .. a.aid .. ")" end

-- Pick attributes from the drop-down choice → list of { aid, on, name }.
local function select_attributes(all, choice)
  local out = {}
  for _, a in ipairs(all) do
    if choice == ALL_POS and a.on then out[#out + 1] = a
    elseif choice == ALL_NEG and not a.on then out[#out + 1] = a
    elseif choice ~= ALL_POS and choice ~= ALL_NEG and attr_label(a) == choice then out[#out + 1] = a end
  end
  return out
end

-- Attribute calendar: number of finds per day (month × day) for each chosen attribute.
-- datecol: "found_date" (found date) or "hidden_date" (placed date).
local function report_attr_calendar(cfg, attrs, datecol)
  local placed = (datecol == "hidden_date")
  local label = placed and DATE_KINDS[2] or DATE_KINDS[1]
  local counts = {}
  for r in opensak.sql_each(string.format([[
      SELECT a.attribute_id AS aid, a.is_on AS on_, substr(c.%s, 6, 2) AS mm, substr(c.%s, 9, 2) AS dd
      FROM attributes a JOIN caches c ON c.id = a.cache_id
      WHERE c.found = 1 AND c.%s IS NOT NULL AND c.parent_gc_code IS NULL]], datecol, datecol, datecol),
      nil, dbo(cfg.found_db)) do
    local m, d = tonumber(r.mm), tonumber(r.dd)
    if m and d and m >= 1 and m <= 12 and d >= 1 and d <= 31 then
      local k = r.aid .. (r.on_ == 1 and "+" or "-")
      counts[k] = counts[k] or {}
      local cell = m * 100 + d
      counts[k][cell] = (counts[k][cell] or 0) + 1
    end
  end

  local parts, summary = {}, {}
  for _, a in ipairs(attrs) do
    local c = counts[a.aid .. (a.on and "+" or "-")] or {}
    local days_with, total = 0, 0
    local h = { "<h2>" .. esc(attr_label(a)) .. "</h2><table class='cal'><tr><th></th>" }
    for d = 1, 31 do h[#h + 1] = "<th>" .. d .. "</th>" end
    h[#h + 1] = "<th>Σ</th></tr>"
    for m = 1, 12 do
      h[#h + 1] = "<tr><th>" .. MONTHS_SHORT[m] .. "</th>"
      local msum = 0
      for d = 1, 31 do
        if d > DAYS_IN_MONTH[m] then
          h[#h + 1] = "<td class='na'>·</td>"
        else
          local n = c[m * 100 + d] or 0
          msum = msum + n
          if n > 0 then days_with = days_with + 1 end
          h[#h + 1] = "<td class='" .. (n > 0 and "ok" or "miss") .. "'>" .. n .. "</td>"
        end
      end
      total = total + msum
      h[#h + 1] = "<td><b>" .. msum .. "</b></td></tr>"
    end
    h[#h + 1] = "</table>"
    parts[#parts + 1] = table.concat(h)
    summary[#summary + 1] = { name = attr_label(a), days = days_with, total = total, missing = 366 - days_with }
  end
  table.insert(parts, 1, opensak.html.table(summary, {
    columns = { { "name", T("col_attribute") }, { "days", T("col_days_covered") }, { "missing", T("col_days_missing") },
                { "total", T("col_total_finds") } },
    bars = { "days" } }))
  publish(placed and "gc_attribute_calendar_placed.html" or "gc_attribute_calendar.html",
          T("ac_title", label), T("subtitle_found", found_name(cfg)) .. (placed and T("ac_placed_note") or ""), parts)
end

-- Attribute matrix: D/T for each chosen attribute. Green = you have found a cache with the attribute at that D/T,
-- red = missing (with the number of unfound candidates), grey = no candidates.
-- ignore_own: show only the candidates. filter_on: set a filter (only for a single attribute).
local function report_attr_matrix(cfg, attrs, ignore_own, filter_on)
  local found = {}
  for r in opensak.sql_each([[
      SELECT a.attribute_id AS aid, a.is_on AS on_, c.difficulty AS d, c.terrain AS t
      FROM attributes a JOIN caches c ON c.id = a.cache_id
      WHERE c.found = 1 AND c.parent_gc_code IS NULL]], nil, dbo(cfg.found_db)) do
    if r.d and r.t then
      local k = r.aid .. (r.on_ == 1 and "+" or "-")
      found[k] = found[k] or {}
      local dk = key(r.d, r.t)
      found[k][dk] = (found[k][dk] or 0) + 1
    end
  end

  -- Unfound candidates for the chosen attributes
  local want, params = {}, {}
  for _, a in ipairs(attrs) do
    want[#want + 1] = "(a.attribute_id = ? AND a.is_on = ?)"
    params[#params + 1] = a.aid
    params[#params + 1] = a.on and 1 or 0
  end
  local poss = {}
  local centre = opensak.center()
  local use_radius = (cfg.radius or 0) > 0 and centre and centre.lat
  if #want > 0 then
    for r in opensak.sql_each([[
        SELECT a.attribute_id AS aid, a.is_on AS on_, c.gc_code AS code, c.difficulty AS d, c.terrain AS t,
               c.latitude AS lat, c.longitude AS lon
        FROM attributes a JOIN caches c ON c.id = a.cache_id
        WHERE c.found = 0 AND c.archived = 0 AND c.is_owner = 0 AND c.parent_gc_code IS NULL
          AND (]] .. table.concat(want, " OR ") .. ")", params, dbo(cfg.unfound_db)) do
      if r.d and r.t and (not use_radius or
          opensak.coords.distance(centre.lat, centre.lon, r.lat, r.lon) <= cfg.radius) then
        local k = r.aid .. (r.on_ == 1 and "+" or "-")
        poss[k] = poss[k] or {}
        poss[k][#poss[k] + 1] = { code = r.code, key = key(r.d, r.t) }
      end
    end
  end

  local where = radius_text(cfg)
  local parts, summary = {}, {}
  for _, a in ipairs(attrs) do
    local k = a.aid .. (a.on and "+" or "-")
    local near = {}
    for _, p in ipairs(poss[k] or {}) do near[p.key] = (near[p.key] or 0) + 1 end
    local have, possible = 0, 0
    local grid = build_grid(function(d, t)
      local dk = key(d, t)
      local f = found[k] and found[k][dk]
      if f and not ignore_own then
        have = have + 1
        return "ok", big(f, T("wd_finds"))
      end
      local n = near[dk] or 0
      if n > 0 then possible = possible + 1 end
      return (n > 0) and "miss" or "none", big(n, T("unfound_cell", where)), "D " .. r1(d) .. " / T " .. r1(t)
    end)
    parts[#parts + 1] = "<h2>" .. esc(attr_label(a)) .. "</h2>" .. grid
    summary[#summary + 1] = { name = attr_label(a), have = have, possible = possible }
  end
  table.insert(parts, 1, opensak.html.table(summary, {
    columns = { { "name", T("col_attribute") }, { "have", ignore_own and "-" or T("col_dt_found") },
                { "possible", T("col_dt_poss") } } }))
  publish("gc_attribute_matrix.html", T("am_title"), T("subtitle_found", found_name(cfg)), parts)

  if filter_on and #attrs == 1 then
    local a = attrs[1]
    local k = a.aid .. (a.on and "+" or "-")
    local list = {}
    for _, p in ipairs(poss[k] or {}) do
      if ignore_own or not (found[k] and found[k][p.key]) then list[#list + 1] = p end
    end
    set_filter(cfg, list, function() return true end)
  end
end


-- ══════════════════════════════════════════════════════════════════════════
--  CORRECTED COORDINATES → NOTES
-- ══════════════════════════════════════════════════════════════════════════
local NOTE_PATTERN = [[~\*Corrected:[^~]*\*~]]

local function corrected_line(c)
  return "~*Corrected: " .. opensak.coords.format(c.corrected.lat, c.corrected.lon) .. "*~"
end

local function run_corrected(cfg)
  local scope = opensak.choose(T("corr_prompt"), CORR_SCOPES, CORR_SCOPES[2], TITLE)
  if not scope then return end
  local scope_i = index_of(CORR_SCOPES, scope) or 2

  local todo, with_corrected = {}, 0
  local function consider(c)
    if not c.corrected then return end
    with_corrected = with_corrected + 1
    local line = corrected_line(c)
    local note = c.note or ""
    local new
    if note:find("~*Corrected:", 1, true) then
      new = opensak.re.replace(note, NOTE_PATTERN, function() return line end)   -- update the old line
    elseif note ~= "" then
      new = note .. "\n" .. line
    else
      new = line
    end
    if new ~= note then todo[#todo + 1] = { code = c.code, note = new } end
  end

  if scope_i == 1 then
    local c = opensak.current()
    if not c then opensak.message(T("corr_none_selected"), TITLE) return end
    consider(c)
  elseif scope_i == 2 then
    for c in opensak.caches{ fields = { "corrected", "note" } } do consider(c) end
  else
    for c in opensak.caches{ all = true, fields = { "corrected", "note" } } do consider(c) end
  end

  if with_corrected == 0 then
    opensak.message(T("corr_no_coords"), TITLE)
    return
  end
  if #todo == 0 then
    opensak.message(T("corr_all_done", with_corrected), TITLE)
    return
  end
  if not opensak.confirm(T("corr_confirm", #todo, with_corrected)) then return end
  opensak.transaction(function()
    for _, t in ipairs(todo) do opensak.update(t.code, { note = t.note }) end
  end)
  opensak.message(T("corr_done", #todo), TITLE)
end

-- ══════════════════════════════════════════════════════════════════════════
--  IMPORT PQ (zip files in the PQ folder)
-- ══════════════════════════════════════════════════════════════════════════
local function run_import(cfg)
  local folder = cfg.pq_folder
  if not folder or folder == "" or not opensak.folder_exists(folder) then
    opensak.message(T("imp_no_folder", tostring(folder)), TITLE)
    return
  end
  local zips = opensak.list_dir(folder, "*.zip")
  if #zips == 0 then
    opensak.message(T("imp_no_zips", folder), TITLE)
    return
  end
  local target = cfg.import_db ~= "" and cfg.import_db or opensak.database()
  if not opensak.confirm(T("imp_confirm", #zips, folder, target, AFTER_IMPORT[cfg.pq_after])) then return end

  local opts = {}
  if cfg.import_db ~= "" then opts.database = cfg.import_db end
  local r = opensak.import_gpx(folder, opts)
  if not r or r.ok == false then
    opensak.message(T("imp_failed"), TITLE)
    return
  end
  if cfg.pq_after == 2 then
    local sub = opensak.create_folder(folder .. "/" .. T("imported_dir"))
    for _, z in ipairs(zips) do opensak.move_file(z.path, sub .. "/") end
  elseif cfg.pq_after == 3 then
    for _, z in ipairs(zips) do opensak.delete_file(z.path) end
  end
  opensak.message(T("imp_done", r.created or 0, r.updated or 0), TITLE)
end

-- ══════════════════════════════════════════════════════════════════════════
--  HELP
-- ══════════════════════════════════════════════════════════════════════════
local function show_help()
  local spec = { title = T("help_title", TITLE), css = CSS }
  for _, k in ipairs({ "help1", "help2", "help3", "help4" }) do spec[#spec + 1] = T(k) end
  local path = opensak.write_text(opensak.temp_dir() .. "/gc_help.html", opensak.html.page(spec))
  open_report(path)
end

-- ══════════════════════════════════════════════════════════════════════════
--  DIALOGS AND MENU
-- ══════════════════════════════════════════════════════════════════════════
local function with_all(first, list, field)
  local out = { first }
  for _, v in ipairs(list) do out[#out + 1] = field and v[field] or v end
  return out
end

local function act_month(cfg)
  local _, cm = today()
  local v = opensak.form{ title = T("m_month"), fields = {
    { type = "choice", id = "month", label = T("f_month"), options = MONTHS, default = MONTHS[cm] },
    { type = "checkbox", id = "filter", label = T("f_filter_month"), default = true },
  } }
  if not v then return end
  report_month(cfg, index_of(MONTHS, v.month) or cm, v.filter)
end

local function act_streak(cfg)
  local v = opensak.form{ title = T("m_streak"), fields = {
    { type = "choice", id = "mode", label = T("f_filter"), options = STREAK_MODES, default = STREAK_MODES[1] },
  } }
  if not v then return end
  report_streak(cfg, (index_of(STREAK_MODES, v.mode) or 1) - 1)
end

local function act_weekdays(cfg)
  local all = T("all_weekdays")
  local v = opensak.form{ title = T("m_weekday"), fields = {
    { type = "choice", id = "day", label = T("f_weekday"), options = with_all(all, WEEKDAYS), default = all },
    { type = "checkbox", id = "filter", label = T("f_filter_wd"), default = false },
  } }
  if not v then return end
  report_weekdays(cfg, (index_of(WEEKDAYS, v.day) or 0), v.filter)
end

local function act_type_matrix(cfg)
  local all = T("all_types")
  local v = opensak.form{ title = T("m_types"), fields = {
    { type = "choice", id = "typ", label = T("f_type"), options = with_all(all, TYPES, "label"), default = all },
    { type = "checkbox", id = "filter", label = T("f_filter_type"), default = false },
  } }
  if not v then return end
  local ti = 0
  for i, t in ipairs(TYPES) do if t.label == v.typ then ti = i end end
  report_type_matrix(cfg, ti, v.filter)
end

local function act_cache_types(cfg)
  local ty, tm, td = today()
  local none = T("no_filter")
  local v = opensak.form{ title = T("m_missing"), fields = {
    { type = "date", id = "start", label = T("f_start"), default = string.format("%04d-%02d-%02d", ty, tm, td) },
    { type = "number", id = "days", label = T("f_days"), default = 8, min = 1, max = 60, decimals = 0 },
    { type = "choice", id = "wd", label = T("f_filter_ct"), options = with_all(none, WEEKDAYS), default = none },
  } }
  if not v then return end
  report_cache_types(cfg, v.start, math.floor(v.days or 8), index_of(WEEKDAYS, v.wd) or 0)
end

local function act_year_calendar(cfg)
  local labels = {}
  for _, t in ipairs(TYPES) do labels[#labels + 1] = t.label end
  local v = opensak.form{ title = T("m_year"), fields = {
    { type = "choice", id = "typ", label = T("f_type"), options = labels, default = labels[1] },
  } }
  if not v then return end
  for i, t in ipairs(TYPES) do if t.label == v.typ then report_year_calendar(cfg, i) end end
end

local function attribute_options(cfg)
  local all = attribute_choices(cfg)
  if #all == 0 then
    opensak.message(T("no_attrs"), TITLE)
    return nil
  end
  local opts = { ALL_POS, ALL_NEG }
  for _, a in ipairs(all) do opts[#opts + 1] = attr_label(a) end
  return all, opts
end

local function act_attr_calendar(cfg)
  local all, opts = attribute_options(cfg)
  if not all then return end
  local v = opensak.form{ title = T("m_attrc"), fields = {
    { type = "choice", id = "attr", label = T("f_attr"), options = opts, default = ALL_POS },
    { type = "choice", id = "kind", label = T("f_datekind"), options = DATE_KINDS, default = DATE_KINDS[1] },
  } }
  if not v then return end
  report_attr_calendar(cfg, select_attributes(all, v.attr), v.kind == DATE_KINDS[2] and "hidden_date" or "found_date")
end

local function act_attr_matrix(cfg)
  local all, opts = attribute_options(cfg)
  if not all then return end
  local v = opensak.form{ title = T("m_attrm"), fields = {
    { type = "choice", id = "attr", label = T("f_attr"), options = opts, default = ALL_POS },
    { type = "checkbox", id = "ignore", label = T("f_ignore_own"), default = false },
    { type = "checkbox", id = "filter", label = T("f_filter_attr"), default = false },
  } }
  if not v then return end
  report_attr_matrix(cfg, select_attributes(all, v.attr), v.ignore, v.filter)
end

local ACTIONS = {
  { id = "month",   key = "m_month",   fn = act_month },
  { id = "streak",  key = "m_streak",  fn = act_streak },
  { id = "weekday", key = "m_weekday", fn = act_weekdays },
  { id = "types",   key = "m_types",   fn = act_type_matrix },
  { id = "missing", key = "m_missing", fn = act_cache_types },
  { id = "year",    key = "m_year",    fn = act_year_calendar },
  { id = "attrm",   key = "m_attrm",   fn = act_attr_matrix },
  { id = "attrc",   key = "m_attrc",   fn = act_attr_calendar },
  { id = "corr",    key = "m_corr",    fn = run_corrected },
  { id = "import",  key = "m_import",  fn = run_import },
  { id = "config",  key = "m_config",  fn = edit_settings },
  { id = "help",    key = "m_help",    fn = show_help },
}

local function main()
  local cfg = load_cfg()
  while true do
    local radius = (cfg.radius or 0) > 0 and (cfg.radius .. " km") or T("radius_none")
    local fields = {
      { type = "label", label = T("menu_status", cfg.found_db ~= "" and cfg.found_db or opensak.database(),
                                  cfg.unfound_db ~= "" and cfg.unfound_db or opensak.database(), radius) },
      { type = "separator" },
    }
    for _, a in ipairs(ACTIONS) do fields[#fields + 1] = { type = "button", id = a.id, label = T(a.key) } end
    local v, btn = opensak.form{ title = TITLE, fields = fields,
                                 buttons = { { id = "close", label = T("m_close"), cancel = true } } }
    if not v or btn == "close" then break end
    for _, a in ipairs(ACTIONS) do
      if a.id == btn then
        local ok, err = pcall(a.fn, cfg)
        if not ok then
          print("Error in " .. a.id .. ": " .. tostring(err))
          opensak.message(T("error_msg", T(a.key), tostring(err)), TITLE)
        end
      end
    end
  end
end

if GC_TEST then
  GC_API = { report_month = report_month, report_streak = report_streak, report_weekdays = report_weekdays,
             report_type_matrix = report_type_matrix, report_cache_types = report_cache_types,
             report_year_calendar = report_year_calendar, report_attr_calendar = report_attr_calendar,
             report_attr_matrix = report_attr_matrix, run_corrected = run_corrected, run_import = run_import,
             attribute_choices = attribute_choices, select_attributes = select_attributes, load_cfg = load_cfg,
             main = main, weekday_of = weekday_of, show_help = show_help, ACTIONS = ACTIONS, MONTHS = MONTHS,
             edit_settings = edit_settings, set_lang = apply_lang, T = T, STR = STR, AFTER_IMPORT = AFTER_IMPORT,
             DATE_KINDS = DATE_KINDS, CORR_SCOPES = CORR_SCOPES, WEEKDAYS = WEEKDAYS,
             get_title = function() return TITLE end }
else
  main()
end
